CREATE TABLE orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255),
  email VARCHAR(255),
  phone VARCHAR(50),
  address TEXT,
  delivery VARCHAR(50),
  note TEXT,
  items TEXT, -- Added to store product details
  total DECIMAL(10, 2), -- Added to store the total price
  print_image VARCHAR(255), -- Added to store the print image path
  preview_image VARCHAR(255), -- Added to store the preview image path
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
